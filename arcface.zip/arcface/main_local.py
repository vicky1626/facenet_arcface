import cv2
import numpy as np
import torch
from facenet_pytorch import MTCNN, InceptionResnetV1
import joblib

# Initialize device and models
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
detector = MTCNN(keep_all=True, device=device)
embedding_model = InceptionResnetV1(pretrained='vggface2').eval().to(device)
classifier = joblib.load('face_classifier.joblib')

def extract_face_embeddings(frame, boxes):
    faces = []
    if boxes is not None:
        for box in boxes:
            left, top, right, bottom = map(int, box)
            if left < 0 or top < 0 or right > frame.shape[1] or bottom > frame.shape[0]:
                continue

            face = frame[top:bottom, left:right]
            if face.size == 0:
                continue

            face = cv2.resize(face, (250, 250))  # Resize face to 250x250
            face = (face / 255.0).astype(np.float32)  # Normalize
            face = torch.tensor(face).permute(2, 0, 1).unsqueeze(0).to(device)  # Convert to tensor
            with torch.no_grad():
                embedding = embedding_model(face).cpu().numpy().flatten()
            faces.append(embedding)
    return faces

def get_dist(rectangle_params, focal_length=700, real_width=14.3):
    left, top, right, bottom = rectangle_params
    width_pixels = right - left
    dist = (real_width * focal_length) / width_pixels
    return dist

def recognize_faces(frame):
    img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    boxes, _ = detector.detect(img_rgb)
    faces = extract_face_embeddings(frame, boxes)
    
    recognized_faces = []
    if faces:
        for face_embedding in faces:
            probabilities = classifier.predict_proba([face_embedding])[0]
            max_prob = probabilities.max()
            predicted_label = classifier.predict([face_embedding])[0]
            
            if max_prob >= 0.5:
                recognized_faces.append({
                    "label": predicted_label,
                    "probability": max_prob
                })
    return recognized_faces, boxes

def main():
    cap = cv2.VideoCapture(2)
    
    while True:
        success, frame = cap.read()
        if not success:
            print("Failed to grab frame")
            break
        
        recognized_faces, boxes = recognize_faces(frame)
        
        # Draw bounding boxes and results on the frame
        if boxes is not None:
            for i, box in enumerate(boxes):
                left, top, right, bottom = map(int, box)
                
                # Calculate the distance and filter out invalid boxes
                distance = get_dist(box)
                if distance < 50 or distance > 200:  # Example threshold, adjust as needed
                    continue
                
                if left < 0 or top < 0 or right >= frame.shape[1] or bottom >= frame.shape[0]:
                    continue

                # Draw bounding box
                cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0), 2)
                
                # Draw label and probability
                if i < len(recognized_faces):
                    face = recognized_faces[i]
                    label = face['label']
                    probability = face['probability'] * 100
                    text = f"{label}: {probability:.2f}%"
                    (text_width, text_height), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)
                    
                    # Draw background rectangle for text
                    cv2.rectangle(frame, (left, top - text_height - 10), (left + text_width, top), (0, 255, 0), -1)
                    
                    # Draw text above bounding box
                    cv2.putText(frame, text, (left, top - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        
        # Display the frame
        cv2.imshow('Face Recognition', frame)
        
        # Exit the loop when 'q' is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
