import os
import cv2
import torch
import numpy as np
import joblib
from facenet_pytorch import MTCNN, InceptionResnetV1
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, roc_curve, auc
import matplotlib.pyplot as plt
from sklearn.model_selection import cross_val_score

# Initialize device and models
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
detector = MTCNN(keep_all=True, device=device)
embedding_model = InceptionResnetV1(pretrained='vggface2').eval().to(device)

# Directory paths
dataset_dir = "train"
processed_dir = "processed_faces"
output_folder = "output_metrics"

if not os.path.exists(processed_dir):
    os.makedirs(processed_dir)
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

def extract_face_embeddings(img, boxes):
    faces = []
    for box in boxes:
        left, top, right, bottom = map(int, box)
        face = img[top:bottom, left:right]
        face = cv2.resize(face, (250, 250))  # Resize face to 250x250
        face = (face / 255.0).astype(np.float32)  # Normalize
        face = torch.tensor(face).permute(2, 0, 1).unsqueeze(0).to(device)  # Convert to tensor
        with torch.no_grad():
            embedding = embedding_model(face).cpu().numpy()
        faces.append(embedding.flatten())
    return faces

def process_and_save_faces():
    for person_name in os.listdir(dataset_dir):
        person_path = os.path.join(dataset_dir, person_name)
        if os.path.isdir(person_path):
            output_person_dir = os.path.join(processed_dir, person_name)
            if not os.path.exists(output_person_dir):
                os.makedirs(output_person_dir)
            for image_name in os.listdir(person_path):
                image_path = os.path.join(person_path, image_name)
                img = cv2.imread(image_path)
                if img is None:
                    print(f"Error reading image: {image_path}")
                    continue
                boxes, _ = detector.detect(img)
                if boxes is None:
                    print(f"No faces detected in {image_path}")
                    continue
                faces = extract_face_embeddings(img, boxes)
                for i, face_embedding in enumerate(faces):
                    output_image_path = os.path.join(output_person_dir, f"{os.path.splitext(image_name)[0]}_{i}.jpg")
                    cv2.imwrite(output_image_path, img)
                    np.save(output_image_path.replace('.jpg', '.npy'), face_embedding)
                print(f"Processed {image_path}")

def load_embeddings(processed_dir):
    embeddings = []
    labels = []
    for person_name in os.listdir(processed_dir):
        person_path = os.path.join(processed_dir, person_name)
        if os.path.isdir(person_path):
            for image_name in os.listdir(person_path):
                if image_name.endswith('.npy'):
                    embedding = np.load(os.path.join(person_path, image_name))
                    embeddings.append(embedding)
                    labels.append(person_name)
    return np.array(embeddings), np.array(labels)

def plot_confusion_matrix(cm, classes, output_folder):
    plt.figure(figsize=(10, 7))
    plt.imshow(cm, interpolation='nearest', cmap=plt.cm.Blues)
    plt.title('Confusion Matrix')
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)
    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.tight_layout()
    plt.savefig(os.path.join(output_folder, 'confusion_matrix.png'))
    plt.close()

def plot_roc_curve(y_test, y_score, class_names, output_folder):
    plt.figure(figsize=(10, 7))
    for i, class_name in enumerate(class_names):
        fpr, tpr, _ = roc_curve(y_test == class_name, y_score[:, i])
        roc_auc = auc(fpr, tpr)
        plt.plot(fpr, tpr, label=f'{class_name} (area = {roc_auc:.2f})')
    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic (ROC)')
    plt.legend(loc="lower right")
    plt.savefig(os.path.join(output_folder, 'roc_curve.png'))
    plt.close()

def calculate_tp_fp_fn_tn(cm):
    TP = np.diag(cm)
    FP = np.sum(cm, axis=0) - TP
    FN = np.sum(cm, axis=1) - TP
    TN = cm.sum() - (TP + FP + FN)
    return TP, FP, FN, TN

def calculate_metrics(TP, FP, FN, TN):
    precision = TP / (TP + FP + 1e-10)  # Added small constant to avoid division by zero
    recall = TP / (TP + FN + 1e-10)     # Added small constant to avoid division by zero
    accuracy = (TP + TN) / (TP + FP + FN + TN + 1e-10)  # Added small constant to avoid division by zero
    return np.mean(precision) * 100, np.mean(recall) * 100, accuracy * 100


def train_and_evaluate_classifier(embeddings, labels):
    X_train, X_test, y_train, y_test = train_test_split(embeddings, labels, test_size=0.2, random_state=42)

    model = SVC(probability=True, C=1.0, kernel='linear')
    model.fit(X_train, y_train)

    # Perform cross-validation
    cv_scores = cross_val_score(model, X_train, y_train, cv=5)
    print("Cross-validation scores:", cv_scores)
    print("Mean cross-validation score:", np.mean(cv_scores))

    # Make predictions on the test set
    y_pred = model.predict(X_test)
    y_score = model.predict_proba(X_test)

    # Calculate and print accuracy
    accuracy = accuracy_score(y_test, y_pred)
    print(f'Accuracy: {accuracy * 100:.2f}%')

    # Generate and print classification report
    print("Classification Report:")
    print(classification_report(y_test, y_pred))

    # Generate confusion matrix
    cm = confusion_matrix(y_test, y_pred)
    print("Confusion Matrix:")
    print(cm)
    
    # Plot confusion matrix
    plot_confusion_matrix(cm, classes=np.unique(labels), output_folder=output_folder)

    # Plot ROC curve
    plot_roc_curve(y_test, y_score, class_names=np.unique(labels), output_folder=output_folder)

    # Calculate TP, FP, FN, TN
    TP, FP, FN, TN = calculate_tp_fp_fn_tn(cm)

    # Calculate metrics
    precision_percentage, recall_percentage, accuracy_percentage = calculate_metrics(TP, FP, FN, TN)
    print(f'Precision per class: {precision_percentage}')
    print(f'Recall per class: {recall_percentage}')

    # Save the model
    joblib.dump(model, "face_classifier.joblib")
    print("Model saved as face_classifier.joblib")



if __name__ == "__main__":
    process_and_save_faces()
    embeddings, labels = load_embeddings(processed_dir)
    train_and_evaluate_classifier(embeddings, labels)
