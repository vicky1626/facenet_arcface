from flask import Flask, render_template, Response, jsonify
import cv2
import joblib
import torch
from facenet_pytorch import MTCNN, InceptionResnetV1
import numpy as np

app = Flask(__name__)

# Initialize FaceNet model and classifier
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
embedding_model = InceptionResnetV1(pretrained='vggface2').eval().to(device)
classifier = joblib.load('face_classifier.joblib')

# Initialize MTCNN for face detection
detector = MTCNN(keep_all=True, device=device)

# Global variable to store the latest recognized faces results
recognized_faces = []

def extract_face_embeddings(frame, boxes):
    faces = []
    if boxes is not None:
        for box in boxes:
            left, top, right, bottom = map(int, box)
            if left < 0 or top < 0 or right > frame.shape[1] or bottom > frame.shape[0]:
                print(f"Skipping box out of bounds: {box}")
                continue

            face = frame[top:bottom, left:right]
            if face.size == 0:  # Check if face is empty
                print(f"Empty face region for box: {box}")
                continue

            face = cv2.resize(face, (250, 250))  # Resize face to 250x250
            face = (face / 255.0).astype(np.float32)  # Normalize
            face = torch.tensor(face).permute(2, 0, 1).unsqueeze(0).to(device)  # Convert to tensor
            with torch.no_grad():
                embedding = embedding_model(face).cpu().numpy().flatten()
            faces.append(embedding)
    else:
        print("No faces detected")

    return faces


def recognize_faces(frame, model, classifier, confidence_threshold=0.5, max_faces=5):
    global recognized_faces
    recognized_faces = []

    boxes, _ = detector.detect(frame)
    if boxes is not None:
        face_embeddings = extract_face_embeddings(frame, boxes)
        for embedding in face_embeddings:
            probabilities = classifier.predict_proba([embedding])[0]
            max_prob = probabilities.max()
            predicted_label = classifier.predict([embedding])[0]

            if max_prob >= confidence_threshold:
                recognized_faces.append({
                    "label": predicted_label,
                    "probability": max_prob
                })

    return frame

def generate_frames():
    cap = cv2.VideoCapture(0)
    global recognized_faces
    while True:
        success, frame = cap.read()
        if not success:
            break
        else:
            frame = recognize_faces(frame, embedding_model, classifier)
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()

            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    cap.release()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/results')
def results():
    global recognized_faces
    results_list = []
    for face in recognized_faces:
        results_list.append(f"RESULT: {face['label']} IS DETECTED WITH {face['probability'] * 100:.2f} PERCENTAGE")
    if not results_list:
        results_list.append("No faces detected")
    return jsonify(results_list)

if __name__ == '__main__':
    app.run(debug=True)
