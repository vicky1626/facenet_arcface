import cv2
import os

def list_available_cameras():
    index = 3
    available_cameras = []
    while True:
        cap = cv2.VideoCapture(index)
        if not cap.isOpened():
            break
        available_cameras.append(index)
        cap.release()
        index += 1
    return available_cameras

def select_camera():
    cameras = list_available_cameras()
    if not cameras:
        print("No cameras found.")
        return None

    print("Available cameras:", cameras)
    choice = int(input("Select the camera index to use: "))
    if choice in cameras:
        return choice
    else:
        print("Invalid camera index.")
        return None

# Prompt for the name of the person
name = input("Enter the name of the person: ")

# Select camera index
camera_index = select_camera()
if camera_index is None:
    exit()

# Set up the webcam
cap = cv2.VideoCapture(camera_index)

# Check if the webcam is opened correctly
if not cap.isOpened():
    print("Error: Could not open webcam.")
    exit()

# Directory settings
directory = os.path.join("captured_frames", name)
if not os.path.exists(directory):
    os.makedirs(directory)

# Frame capture settings
frame_count = 200
captured_frames = 0

while captured_frames < frame_count:
    ret, frame = cap.read()

    if not ret:
        print(f"Warning: Could not read frame {captured_frames}. Retrying...")
        continue  # Skip to the next iteration to try reading the frame again

    # Save the frame with filenames like 1.jpg, 2.jpg, etc.
    file_path = os.path.join(directory, f"{captured_frames + 1}.png")
    cv2.imwrite(file_path, frame)
    captured_frames += 1

# Release the webcam
cap.release()
cv2.destroyAllWindows()

print(f"Captured {captured_frames} frames and saved them to '{directory}'.")

