from flask import Flask, render_template, Response, jsonify
import cv2
import joblib
import torch
from facenet_pytorch import InceptionResnetV1

app = Flask(__name__)

# Initialize FaceNet model and classifier
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
model = InceptionResnetV1(pretrained='vggface2').eval().to(device)
classifier = joblib.load('face_classifier.joblib')

# Global variable to store the latest recognized faces results
recognized_faces = []

def recognize_faces(frame, model, classifier, confidence_threshold=0.5, max_faces=5):
    global recognized_faces
    recognized_faces = []

    img_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    img_rgb = cv2.resize(img_rgb, (160, 160))
    img_tensor = torch.tensor(img_rgb).permute(2, 0, 1).float().unsqueeze(0).to(device)
    
    with torch.no_grad():
        embedding = model(img_tensor).cpu().numpy().flatten()

    probabilities = classifier.predict_proba([embedding])[0]
    max_prob = probabilities.max()
    predicted_label = classifier.predict([embedding])[0]

    if max_prob >= confidence_threshold:
        recognized_faces.append({
            "label": predicted_label,
            "probability": max_prob
        })

    return frame

def generate_frames():
    cap = cv2.VideoCapture(3)
    global recognized_faces
    while True:
        success, frame = cap.read()
        if not success:
            break
        else:
            recognize_faces(frame, model, classifier)
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()

            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    cap.release()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/results')
def results():
    global recognized_faces
    results_list = []
    for face in recognized_faces:
        results_list.append(f"RESULT: {face['label']} IS DETECTED WITH {face['probability'] * 100:.2f} PERCENTAGE")
    if not results_list:
        results_list.append("No faces detected")
    return jsonify(results_list)

if __name__ == '__main__':
    app.run(debug=True)

