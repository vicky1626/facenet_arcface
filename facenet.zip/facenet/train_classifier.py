import os
import cv2
import joblib
import numpy as np
import torch
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import confusion_matrix, classification_report, accuracy_score, precision_score, recall_score, roc_curve, auc
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import label_binarize
from facenet_pytorch import InceptionResnetV1

def create_embeddings(image_folder, model, device):
    embeddings = []
    labels = []
    
    for person_name in os.listdir(image_folder):
        person_path = os.path.join(image_folder, person_name)
        if os.path.isdir(person_path):
            for image_name in os.listdir(person_path):
                image_path = os.path.join(person_path, image_name)
                img = cv2.imread(image_path)
                
                if img is None:
                    print(f"Error reading image: {image_path}")
                    continue
                
                img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
                img_rgb = cv2.resize(img_rgb, (160, 160))
                img_tensor = torch.tensor(img_rgb).permute(2, 0, 1).float().unsqueeze(0).to(device)
                
                embedding = model(img_tensor).detach().cpu().numpy().flatten()
                embeddings.append(embedding)
                labels.append(person_name)
    
    embeddings = np.array(embeddings)
    labels = np.array(labels)
    
    if embeddings.size == 0:
        raise ValueError("No embeddings were extracted. Check the face detection and image reading process.")
    
    print("Embeddings shape:", embeddings.shape)
    print("Labels shape:", labels.shape)
    print("Sample embedding:", embeddings[0] if embeddings.shape[0] > 0 else "No embeddings found")
    
    return embeddings, labels

def plot_confusion_matrix(cm, classes, output_folder):
    plt.figure(figsize=(10, 7))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=classes, yticklabels=classes)
    plt.xlabel('Predicted Label')
    plt.ylabel('True Label')
    plt.title('Confusion Matrix')
    plt.savefig(os.path.join(output_folder, 'confusion_matrix.png'))
    plt.close()

def plot_roc_curve(y_test, y_score, class_names, output_folder):
    y_test_bin = label_binarize(y_test, classes=class_names)
    n_classes = len(class_names)

    # Compute ROC curve and AUC for each class
    fpr = dict()
    tpr = dict()
    roc_auc = dict()

    for i in range(n_classes):
        fpr[i], tpr[i], _ = roc_curve(y_test_bin[:, i], y_score[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])

    # Compute micro-average ROC curve and AUC
    fpr["micro"], tpr["micro"], _ = roc_curve(y_test_bin.ravel(), y_score.ravel())
    roc_auc["micro"] = auc(fpr["micro"], tpr["micro"])

    # Plot ROC curves
    plt.figure(figsize=(10, 6))  # Adjust the figure size if needed
    plt.plot(fpr["micro"], tpr["micro"], color='deeppink', lw=2, label=f'micro-average ROC curve (area = {roc_auc["micro"]:.2f})')

    # Use colormap from matplotlib.pyplot
    colors = plt.get_cmap('tab20', n_classes)
    for i in range(n_classes):
        plt.plot(fpr[i], tpr[i], color=colors(i / n_classes), lw=2, label=f'class {class_names[i]} (area = {roc_auc[i]:.2f})')

    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver Operating Characteristic')

    # Position the legend outside the plot
    plt.legend(loc='center left', bbox_to_anchor=(1, 0.5), fontsize='small')

    plt.tight_layout(rect=[0, 0, 0.85, 1])  # Adjust layout to make space for the legend
    plt.savefig(os.path.join(output_folder, 'roc_curve.png'))
    plt.close()

def main():
    # Hardcoded path to the training images
    image_folder = 'train/'
    output_folder = '.'
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    # Initialize FaceNet model
    model = InceptionResnetV1(pretrained='vggface2').eval().to(device)

    # Create embeddings and labels from training images
    embeddings, labels = create_embeddings(image_folder, model, device)
    
    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(embeddings, labels, test_size=0.2, random_state=42)

    # Experiment with different SVM parameters
    model_svm = SVC(probability=True, C=0.1)

    # Cross-validation with the SVM model
    cv_scores = cross_val_score(model_svm, X_train, y_train, cv=5)
    print("Cross-validation scores:", cv_scores)
    print("Mean cross-validation score:", np.mean(cv_scores))

    # Train the SVM model
    model_svm.fit(X_train, y_train)

    # Save the trained model
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)
    joblib.dump(model_svm, os.path.join(output_folder, 'face_classifier.joblib'))
    print("Model trained and saved as face_classifier.joblib")

    # Evaluate the model
    y_pred = model_svm.predict(X_test)
    y_score = model_svm.predict_proba(X_test)

    # Confusion Matrix
    cm = confusion_matrix(y_test, y_pred, labels=model_svm.classes_)
    plot_confusion_matrix(cm, model_svm.classes_, output_folder)

    # ROC Curve
    plot_roc_curve(y_test, y_score, model_svm.classes_, output_folder)

    # Classification Report
    report = classification_report(y_test, y_pred, target_names=model_svm.classes_)
    print("Classification Report:\n", report)

    # Accuracy, Precision, Recall
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average='weighted')
    recall = recall_score(y_test, y_pred, average='weighted')

    print(f"Accuracy: {accuracy:.2f}")
    print(f"Precision: {precision:.2f}")
    print(f"Recall: {recall:.2f}")

if __name__ == "__main__":
    main()
